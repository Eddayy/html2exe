import { Cpu, HardDrive, Wifi, Battery } from "lucide-react";
import { StatCard } from "@/components/StatCard";
import { ChartCard } from "@/components/ChartCard";

// Generate random data for demo
const generateRandomData = (length: number, min: number, max: number) => {
  return Array.from({ length }, (_, i) => ({
    name: `${i}:00`,
    value: Math.floor(Math.random() * (max - min + 1)) + min,
  }));
};

const cpuData = generateRandomData(24, 20, 90);
const memoryData = generateRandomData(24, 30, 85);

export default function Performance() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Performance</h1>
        <p className="text-muted-foreground mt-2">
          System performance metrics and monitoring.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="CPU Usage"
          value="45.3%"
          change={3.2}
          changeType="increase"
          icon={Cpu}
          gradient
        />
        <StatCard
          title="Memory"
          value="67.8%"
          change={1.4}
          changeType="decrease"
          icon={HardDrive}
        />
        <StatCard
          title="Network"
          value="156 Mbps"
          change={12.3}
          changeType="increase"
          icon={Wifi}
        />
        <StatCard
          title="Uptime"
          value="99.9%"
          change={0.1}
          changeType="increase"
          icon={Battery}
        />
      </div>

      {/* Charts Grid */}
      <div className="grid gap-6 lg:grid-cols-2">
        <ChartCard
          title="CPU Usage (24h)"
          data={cpuData}
          type="line"
          dataKey="value"
          color="hsl(var(--dashboard-error))"
        />
        <ChartCard
          title="Memory Usage (24h)"
          data={memoryData}
          type="area"
          dataKey="value"
          color="hsl(var(--dashboard-warning))"
        />
      </div>

      {/* System metrics */}
      <div className="grid gap-6 md:grid-cols-3">
        <StatCard
          title="Disk I/O"
          value="234 MB/s"
          change={6.7}
          changeType="increase"
          icon={HardDrive}
        />
        <StatCard
          title="Response Time"
          value="127ms"
          change={15.2}
          changeType="decrease"
          icon={Cpu}
          gradient
        />
        <StatCard
          title="Error Rate"
          value="0.03%"
          change={45.8}
          changeType="decrease"
          icon={Battery}
        />
      </div>
    </div>
  );
}