import { Eye, MousePointer, Clock, Globe } from "lucide-react";
import { StatCard } from "@/components/StatCard";
import { ChartCard } from "@/components/ChartCard";

// Generate random data for demo
const generateRandomData = (length: number, min: number, max: number) => {
  return Array.from({ length }, (_, i) => ({
    name: `Week ${i + 1}`,
    value: Math.floor(Math.random() * (max - min + 1)) + min,
  }));
};

const pageViewsData = generateRandomData(12, 2000, 8000);
const conversionData = generateRandomData(7, 10, 50);

export default function Analytics() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Analytics</h1>
        <p className="text-muted-foreground mt-2">
          Detailed insights into your website performance.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Page Views"
          value="98,456"
          change={23.1}
          changeType="increase"
          icon={Eye}
        />
        <StatCard
          title="Click Rate"
          value="3.24%"
          change={5.7}
          changeType="increase"
          icon={MousePointer}
          gradient
        />
        <StatCard
          title="Avg. Session"
          value="4m 32s"
          change={2.1}
          changeType="decrease"
          icon={Clock}
        />
        <StatCard
          title="Countries"
          value="47"
          change={8.9}
          changeType="increase"
          icon={Globe}
        />
      </div>

      {/* Charts Grid */}
      <div className="grid gap-6 lg:grid-cols-2">
        <ChartCard
          title="Page Views Over Time"
          data={pageViewsData}
          type="bar"
          dataKey="value"
          color="hsl(var(--dashboard-accent))"
        />
        <ChartCard
          title="Conversion Rate"
          data={conversionData}
          type="area"
          dataKey="value"
          color="hsl(var(--dashboard-warning))"
        />
      </div>

      {/* Additional metrics */}
      <div className="grid gap-6 md:grid-cols-3">
        <StatCard
          title="Bounce Rate"
          value="24.3%"
          change={4.2}
          changeType="decrease"
          icon={Eye}
        />
        <StatCard
          title="New Visitors"
          value="67.8%"
          change={11.5}
          changeType="increase"
          icon={Globe}
          gradient
        />
        <StatCard
          title="Page Load Time"
          value="1.24s"
          change={8.1}
          changeType="decrease"
          icon={Clock}
        />
      </div>
    </div>
  );
}