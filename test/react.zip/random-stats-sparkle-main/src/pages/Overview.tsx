import { Users, DollarSign, ShoppingCart, Activity } from "lucide-react";
import { StatCard } from "@/components/StatCard";
import { ChartCard } from "@/components/ChartCard";

// Generate random data for demo
const generateRandomData = (length: number, min: number, max: number) => {
  return Array.from({ length }, (_, i) => ({
    name: `Day ${i + 1}`,
    value: Math.floor(Math.random() * (max - min + 1)) + min,
  }));
};

const revenueData = generateRandomData(7, 1000, 5000);
const usersData = generateRandomData(7, 100, 800);

export default function Overview() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Overview</h1>
        <p className="text-muted-foreground mt-2">
          Here's what's happening with your dashboard today.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Users"
          value="12,543"
          change={12.5}
          changeType="increase"
          icon={Users}
          gradient
        />
        <StatCard
          title="Revenue"
          value="$45,231"
          change={8.2}
          changeType="increase"
          icon={DollarSign}
        />
        <StatCard
          title="Orders"
          value="1,259"
          change={3.8}
          changeType="decrease"
          icon={ShoppingCart}
        />
        <StatCard
          title="Active Sessions"
          value="847"
          change={15.3}
          changeType="increase"
          icon={Activity}
        />
      </div>

      {/* Charts Grid */}
      <div className="grid gap-6 lg:grid-cols-2">
        <ChartCard
          title="Revenue Trend"
          data={revenueData}
          type="area"
          dataKey="value"
          color="hsl(var(--dashboard-accent))"
        />
        <ChartCard
          title="User Growth"
          data={usersData}
          type="line"
          dataKey="value"
          color="hsl(var(--dashboard-success))"
        />
      </div>
    </div>
  );
}