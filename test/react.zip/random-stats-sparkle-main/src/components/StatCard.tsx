import { LucideIcon, TrendingUp, TrendingDown } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface StatCardProps {
  title: string;
  value: string | number;
  change?: number;
  changeType?: "increase" | "decrease";
  icon: LucideIcon;
  gradient?: boolean;
}

export function StatCard({ 
  title, 
  value, 
  change, 
  changeType = "increase", 
  icon: Icon,
  gradient = false 
}: StatCardProps) {
  return (
    <Card className={cn(
      "relative overflow-hidden transition-colors hover:bg-dashboard-card-hover",
      gradient && "bg-gradient-to-br from-dashboard-card to-dashboard-card-hover"
    )}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold text-foreground mt-2">{value}</p>
            {change !== undefined && (
              <div className={cn(
                "flex items-center mt-2 text-sm",
                changeType === "increase" ? "text-dashboard-success" : "text-dashboard-error"
              )}>
                {changeType === "increase" ? (
                  <TrendingUp className="mr-1 h-4 w-4" />
                ) : (
                  <TrendingDown className="mr-1 h-4 w-4" />
                )}
                {Math.abs(change)}%
              </div>
            )}
          </div>
          <div className={cn(
            "p-3 rounded-lg",
            gradient 
              ? "bg-dashboard-accent/20" 
              : "bg-dashboard-accent/10"
          )}>
            <Icon className={cn(
              "h-6 w-6",
              gradient 
                ? "text-dashboard-accent-light" 
                : "text-dashboard-accent"
            )} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}