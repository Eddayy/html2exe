// Global variables
let counter = 0;
let currentTheme = 'default';

// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    console.log('Sample Multi-Page App initialized successfully!');
    
    // Load saved counter value
    const savedCounter = localStorage.getItem('counter');
    if (savedCounter) {
        counter = parseInt(savedCounter);
        updateCounterDisplay();
    }
    
    // Load saved theme
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        setTheme(savedTheme);
    }
    
    // Initialize contact form if it exists
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', handleContactForm);
    }
    
    // Load saved storage data if on features page
    if (document.getElementById('storageResult')) {
        loadStorageDisplay();
    }
}

// Navigation functions
function showAlert() {
    alert('Welcome to the Sample Multi-Page App! This demonstrates JavaScript functionality in your Wails desktop application.');
}

// Counter functions
function incrementCounter() {
    counter++;
    updateCounterDisplay();
    saveCounter();
    animateButton(event.target);
}

function decrementCounter() {
    counter--;
    updateCounterDisplay();
    saveCounter();
    animateButton(event.target);
}

function resetCounter() {
    counter = 0;
    updateCounterDisplay();
    saveCounter();
    animateButton(event.target);
}

function updateCounterDisplay() {
    const counterElement = document.getElementById('counterValue');
    if (counterElement) {
        counterElement.textContent = counter;
        
        // Add animation
        counterElement.style.transform = 'scale(1.2)';
        setTimeout(() => {
            counterElement.style.transform = 'scale(1)';
        }, 150);
    }
}

function saveCounter() {
    localStorage.setItem('counter', counter.toString());
}

// Theme functions
function setTheme(theme) {
    currentTheme = theme;
    document.body.className = theme === 'default' ? '' : `theme-${theme}`;
    localStorage.setItem('theme', theme);
    
    // Show feedback
    showNotification(`Theme changed to ${theme}`, 'success');
}

// Text animation functions
function animateText() {
    const textElement = document.getElementById('animatedText');
    if (textElement) {
        textElement.classList.add('animate');
        textElement.textContent = 'Animation Complete! 🎉';
        
        setTimeout(() => {
            textElement.classList.remove('animate');
            textElement.textContent = 'Click the button below!';
        }, 2000);
    }
}

// Storage functions
function saveData() {
    const input = document.getElementById('storageInput');
    const result = document.getElementById('storageResult');
    
    if (input && result) {
        const data = input.value.trim();
        if (data) {
            localStorage.setItem('userData', data);
            localStorage.setItem('saveTimestamp', new Date().toLocaleString());
            result.innerHTML = `<strong>Data Saved:</strong> "${data}"<br><small>Saved at: ${new Date().toLocaleString()}</small>`;
            result.style.background = '#d4edda';
            result.style.borderColor = '#28a745';
            input.value = '';
            animateButton(event.target);
        } else {
            showNotification('Please enter some text first!', 'error');
        }
    }
}

function loadData() {
    const result = document.getElementById('storageResult');
    
    if (result) {
        const data = localStorage.getItem('userData');
        const timestamp = localStorage.getItem('saveTimestamp');
        
        if (data) {
            result.innerHTML = `<strong>Loaded Data:</strong> "${data}"<br><small>Originally saved at: ${timestamp || 'Unknown'}</small>`;
            result.style.background = '#cce5ff';
            result.style.borderColor = '#007bff';
        } else {
            result.innerHTML = '<strong>No Data Found</strong><br><small>Save some data first!</small>';
            result.style.background = '#fff3cd';
            result.style.borderColor = '#ffc107';
        }
        animateButton(event.target);
    }
}

function clearData() {
    const result = document.getElementById('storageResult');
    
    if (result) {
        localStorage.removeItem('userData');
        localStorage.removeItem('saveTimestamp');
        result.innerHTML = '<strong>Data Cleared</strong><br><small>All stored data has been removed</small>';
        result.style.background = '#f8d7da';
        result.style.borderColor = '#dc3545';
        animateButton(event.target);
    }
}

function loadStorageDisplay() {
    const result = document.getElementById('storageResult');
    if (result) {
        const data = localStorage.getItem('userData');
        if (data) {
            const timestamp = localStorage.getItem('saveTimestamp');
            result.innerHTML = `<strong>Previously Saved:</strong> "${data}"<br><small>Saved at: ${timestamp || 'Unknown'}</small>`;
            result.style.background = '#e2e3e5';
            result.style.borderColor = '#6c757d';
        } else {
            result.innerHTML = '<strong>No Stored Data</strong><br><small>Use the form above to test data storage</small>';
            result.style.background = '#f8f9fa';
            result.style.borderColor = '#dee2e6';
        }
    }
}

// Contact form functions
function handleContactForm(event) {
    event.preventDefault();
    
    const form = event.target;
    const resultDiv = document.getElementById('formResult');
    
    // Get form data
    const formData = new FormData(form);
    const data = {
        name: formData.get('name'),
        email: formData.get('email'),
        subject: formData.get('subject'),
        message: formData.get('message'),
        newsletter: formData.get('newsletter') ? 'Yes' : 'No'
    };
    
    // Validate form
    if (!data.name || !data.email || !data.subject || !data.message) {
        showFormResult('Please fill in all required fields.', 'error');
        return;
    }
    
    if (!isValidEmail(data.email)) {
        showFormResult('Please enter a valid email address.', 'error');
        return;
    }
    
    // Simulate form submission
    showFormResult('Processing your message...', 'info');
    
    setTimeout(() => {
        // Store the submission in localStorage for demonstration
        const submissions = JSON.parse(localStorage.getItem('contactSubmissions') || '[]');
        submissions.push({
            ...data,
            timestamp: new Date().toISOString(),
            id: Date.now()
        });
        localStorage.setItem('contactSubmissions', JSON.stringify(submissions));
        
        showFormResult(
            `Thank you, ${data.name}! Your message has been received. We'll get back to you at ${data.email} soon.`,
            'success'
        );
        
        // Reset form
        form.reset();
    }, 1500);
}

function showFormResult(message, type) {
    const resultDiv = document.getElementById('formResult');
    if (resultDiv) {
        resultDiv.textContent = message;
        resultDiv.className = `form-result ${type}`;
        resultDiv.style.display = 'block';
        
        // Auto-hide after 5 seconds for non-error messages
        if (type !== 'error') {
            setTimeout(() => {
                resultDiv.style.display = 'none';
            }, 5000);
        }
    }
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Utility functions
function animateButton(button) {
    if (button) {
        button.style.transform = 'scale(0.95)';
        setTimeout(() => {
            button.style.transform = 'scale(1)';
        }, 150);
    }
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 80px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: 6px;
        color: white;
        font-weight: 500;
        z-index: 10000;
        transform: translateX(100%);
        transition: transform 0.3s ease;
    `;
    
    // Set background color based on type
    switch (type) {
        case 'success':
            notification.style.background = '#28a745';
            break;
        case 'error':
            notification.style.background = '#dc3545';
            break;
        case 'warning':
            notification.style.background = '#ffc107';
            notification.style.color = '#212529';
            break;
        default:
            notification.style.background = '#007bff';
    }
    
    // Add to DOM and animate
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Mobile menu toggle (for future enhancement)
function toggleMobileMenu() {
    const navMenu = document.querySelector('.nav-menu');
    navMenu.classList.toggle('active');
}

// Keyboard shortcuts
document.addEventListener('keydown', function(event) {
    // Ctrl/Cmd + K to show alert
    if ((event.ctrlKey || event.metaKey) && event.key === 'k') {
        event.preventDefault();
        showAlert();
    }
    
    // Ctrl/Cmd + R to reset counter (on features page)
    if ((event.ctrlKey || event.metaKey) && event.key === 'r' && document.getElementById('counterValue')) {
        event.preventDefault();
        resetCounter();
    }
});

// Console welcome message
console.log(`
🎉 Welcome to the Sample Multi-Page App!

This application demonstrates:
- Multi-page navigation
- Interactive JavaScript features
- Local storage functionality
- Form handling and validation
- CSS animations and themes
- Responsive design

Built for testing HTML2EXE conversion with Wails.
`);

// Performance monitoring
window.addEventListener('load', function() {
    const loadTime = performance.now();
    console.log(`✅ App loaded in ${loadTime.toFixed(2)}ms`);
});